package com.example.examen2daparcial

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var nombreEditText: EditText
    private lateinit var controlEditText: EditText
    private lateinit var contactCountTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nombreEditText = findViewById(R.id.nombreEditText)
        controlEditText = findViewById(R.id.controlEditText)
        contactCountTextView = findViewById(R.id.contactCount)

        val agregarButton: Button = findViewById(R.id.agregarButton)
        agregarButton.setOnClickListener { agregarContacto() }

        val verAgendaButton: Button = findViewById(R.id.verAgendaButton)
        verAgendaButton.setOnClickListener { verAgenda() }
    }

    private fun agregarContacto() {
        val nombre = nombreEditText.text.toString()
        val control = controlEditText.text.toString()

        if (nombre.isNotEmpty() && control.isNotEmpty()) {
            ContactRepository.contactos.add(Agenda(nombre, control))
            nombreEditText.text.clear()
            controlEditText.text.clear()
            contactCountTextView.text = "Total contactos: ${ContactRepository.contactos.size}"
        } else {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun verAgenda() {
        val intent = Intent(this, ContactListActivity::class.java)
        startActivity(intent)
    }
}
