package com.example.examen2daparcial

object ContactRepository {
    val contactos = mutableListOf<Agenda>()
}
