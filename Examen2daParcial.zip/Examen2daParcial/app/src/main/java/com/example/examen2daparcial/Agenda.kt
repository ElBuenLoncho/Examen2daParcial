package com.example.examen2daparcial

data class Agenda(val nombre: String, val control: String)
